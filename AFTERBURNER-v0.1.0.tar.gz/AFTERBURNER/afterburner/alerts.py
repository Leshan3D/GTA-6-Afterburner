"""Separate Telegram notifier. No credentials or recipient copied from JAFAR."""
from __future__ import annotations
import logging
import os
import requests
from .storage import iso
LOG = logging.getLogger(__name__)


class Telegram:
    def __init__(self, storage):
        self.storage = storage
        self.token = os.getenv("AFTERBURNER_TELEGRAM_BOT_TOKEN", "").strip()
        self.chat_id = os.getenv("AFTERBURNER_TELEGRAM_CHAT_ID", "").strip()
        self.enabled = bool(self.token and self.chat_id and os.getenv("AFTERBURNER_NO_ALERTS", "0") != "1")

    def send(self, text):
        if not self.enabled:
            LOG.info("Alert notification disabled; message was not sent")
            return False
        try:
            response = requests.post(f"https://api.telegram.org/bot{self.token}/sendMessage",
                                     json={"chat_id": self.chat_id, "text": text[:3800],
                                           "disable_web_page_preview": True}, timeout=10)
            response.raise_for_status()
            if not response.json().get("ok"):
                raise ValueError("Telegram response was not ok")
            return True
        except (requests.RequestException, ValueError) as exc:
            LOG.warning("Telegram send failed (no secrets shown): %s", str(exc).replace(self.token, "[REDACTED]"))
            self.storage.set_health("telegram", "error", "Send failed")
            return False

    def signal(self, asset, snapshot, cooldown_seconds):
        sig = snapshot["signal"]
        if sig["state"] == "MONITOR":
            return False
        key = asset.symbol + ":" + sig["state"] + ":" + sig["bias"]
        if self.storage.seen_alert_recently(key, cooldown_seconds):
            return False
        market = snapshot["market"]
        p = market.get("price")
        price = f"${p:.8f}" if isinstance(p, (int, float)) else "unavailable"
        blocked = ", ".join(sig["blocking_flags"][:4]) or "none"
        message = (f"🔥 AFTERBURNER | {asset.symbol}\n"
                   f"{sig['state']} — {sig['bias']}\n"
                   f"Price: {price}\nLong {sig['long_score']}/100 | Short {sig['short_score']}/100\n"
                   f"Flags: {blocked}\n"
                   f"Game news count (36h): {sig['narrative']['game_articles_36h']}\n"
                   "Research alert only; verify market and define risk manually.\n"
                   f"https://bingx.com/en/perpetual/{asset.symbol}")
        if self.send(message):
            self.storage.record_alert(key, message)
            return True
        return False

    def poll_once(self, status_text):
        """Small read-only command handler, explicitly restricted to configured chat."""
        if not self.enabled:
            return
        try:
            after = int(self.storage.get_kv("telegram_offset", "0"))
            response = requests.get(f"https://api.telegram.org/bot{self.token}/getUpdates",
                                    params={"timeout": 5, "offset": after, "limit": 30}, timeout=9)
            response.raise_for_status()
            body = response.json()
            if not body.get("ok"):
                return
            for item in body.get("result", []):
                offset = item["update_id"] + 1
                msg = item.get("message") or {}
                chat = msg.get("chat") or {}
                incoming = str(msg.get("text", "")).strip().split("@", 1)[0]
                if str(chat.get("id")) == self.chat_id and incoming.startswith(("/meme", "/status", "/help")):
                    self.send(status_text(incoming) if callable(status_text) else str(status_text))
                self.storage.put_kv("telegram_offset", offset)
        except Exception as exc:
            LOG.warning("Telegram poll failed: %s", str(exc).replace(self.token, "[REDACTED]"))
