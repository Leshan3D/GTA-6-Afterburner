"""CLI bootstrap; has no private exchange or order placing capabilities."""
import argparse
import logging
import sys
from .config import ROOT, assets, data_dir, load_env_file, settings, sources
from .service import Radar


def main(argv=None):
    parser = argparse.ArgumentParser(description="AFTERBURNER independent meme futures intelligence (read-only)")
    parser.add_argument("command", choices=["doctor", "once", "serve", "news", "market", "status"])
    parser.add_argument("--verbose", action="store_true")
    opts = parser.parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if opts.verbose else logging.INFO,
                        format="%(asctime)s %(levelname)s %(name)s %(message)s")
    load_env_file()
    if opts.command == "doctor":
        print("AFTERBURNER v0.1.0 / static configuration check (no external API calls)")
        conf = settings()
        watch = assets()
        sources()
        location = data_dir()
        for asset in watch:
            print(f"{asset.symbol} candidate_mint={asset.candidate_mint} verified={asset.mint_verified}")
        print(f"Project: {ROOT}\nDatabase directory: {location}")
        print(f"Dashboard: http://{conf['server']['host']}:{conf['server']['port']}/")
        print("Order execution: NOT IMPLEMENTED / NOT POSSIBLE")
        return 0
    radar = Radar()
    if opts.command == "once":
        print("News:", radar.poll_news())
        print("Markets:", radar.poll_market())
        print(radar.status_text())
    elif opts.command == "news":
        print(radar.poll_news())
    elif opts.command == "market":
        print(radar.poll_market())
    elif opts.command == "status":
        print(radar.status_text())
    elif opts.command == "serve":
        radar.run_forever()
    return 0


if __name__ == "__main__":
    sys.exit(main())
