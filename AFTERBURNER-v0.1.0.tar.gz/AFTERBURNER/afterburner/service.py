"""Single market writer; separate news cadence, Telegram and local Flask server."""
from __future__ import annotations
from datetime import datetime, timezone
import logging
import signal
import threading
import time

from .alerts import Telegram
from .bingx import BingX
from .config import assets as read_assets, settings, sources, data_dir
from .dashboard import build_server
from .dex import DexScreener
from .net import HTTP
from .news import News
from .signals import evaluate
from .storage import Storage, iso

LOG = logging.getLogger(__name__)


class Radar:
    def __init__(self, http=None, store=None):
        self.config = settings()
        self.assets = read_assets()
        self.storage = store or Storage(data_dir() / "afterburner.db")
        sched = self.config["schedule"]
        self.http = http or HTTP(timeout=sched["request_timeout_seconds"],
                                 retries=sched["retries"], pace=sched["request_pace_seconds"])
        self.bingx = BingX(self.http)
        self.dex = DexScreener(self.http)
        self.news = News(self.http, self.storage)
        self.telegram = Telegram(self.storage)
        self.stop_event = threading.Event()

    def poll_news(self):
        counts = self.news.update(sources(), self.assets)
        LOG.info("News checked: %s", counts)
        return counts

    def poll_market(self):
        recent = self.storage.articles(hours=self.config["narrative"]["lookback_hours"])
        count = 0
        for asset in self.assets:
            try:
                market = self.bingx.collect(asset.symbol)
                dex = self.dex.collect(asset)
                old = self.storage.recent_snapshots(asset.symbol, 1)
                sig = evaluate(asset, market, dex, old[0] if old else None, self.config, recent)
                if old is None or len(old) < self.config["risk"].get("min_signal_history_points", 2)-1:
                    sig["state"] = "MONITOR"
                    sig["advisories"].append("warming_up_no_alert")
                self.storage.save_snapshot(asset.symbol, market, dex, sig)
                self.storage.set_health("bingx:"+asset.symbol,
                                        "ok" if all(v == "ok" for v in market["source_health"].values()) else "partial",
                                        "; ".join(k for k,v in market["source_health"].items() if v != "ok")[:300])
                self.storage.set_health("dex:"+asset.symbol,
                                        "ok" if dex.get("status") == "ok" else "partial", dex.get("status", "unknown"))
                if sig["state"] != "MONITOR":
                    self.telegram.signal(asset, {"market":market,"dex":dex,"signal":sig},
                                         self.config["schedule"]["alert_cooldown_seconds"])
                count += 1
                LOG.info("%s price=%s long=%s short=%s status=%s flags=%s",
                         asset.symbol, market.get("price"), sig["long_score"], sig["short_score"],
                         sig["state"], ",".join(sig["blocking_flags"][:3]))
            except Exception as exc:
                LOG.exception("Asset %s cycle failed", asset.symbol)
                self.storage.set_health("bingx:"+asset.symbol, "error", str(exc))
        self.storage.put_kv("market_last_run", iso())
        return count

    def status_text(self, command="/meme"):
        cmd = command.split(maxsplit=1)
        symbol_filter = cmd[1].upper() if len(cmd) == 2 else ""
        if command.startswith("/help"):
            return "AFTERBURNER: /meme — overview; /meme GATO — token; /status — last market/news checks. Research only."
        if command.startswith("/status"):
            return f"AFTERBURNER operational\nMarket: {self.storage.get_kv('market_last_run','never')}\nNews: {self.storage.get_kv('news_last_run','never')}\nOrders: DISABLED"
        lines = ["🔥 AFTERBURNER | RESEARCH ONLY"]
        latest = self.storage.latest([x.symbol for x in self.assets])
        for asset in self.assets:
            if symbol_filter and symbol_filter not in (asset.ticker, asset.symbol):
                continue
            s = latest.get(asset.symbol)
            if not s:
                lines.append(asset.ticker + ": no data yet")
                continue
            m, sig = s["market"], s["signal"]
            age = (datetime.now(timezone.utc)-datetime.fromisoformat(s["collected_at"])).total_seconds()
            stale = " [STALE]" if age > self.config["schedule"]["max_market_age_seconds"] else ""
            lines.append(f"{asset.ticker}: ${m.get('price') or 0:.8f} L{sig['long_score']} S{sig['short_score']} {sig['state']}{stale}")
        return "\n".join(lines)

    def run_forever(self):
        conf = self.config
        host, port = conf["server"]["host"], int(conf["server"]["port"])
        server = build_server(self.storage, self.assets, conf)
        server_thread = threading.Thread(target=server.serve_forever, daemon=True, name="afterburner-dashboard")
        server_thread.start()
        LOG.info("Dashboard http://%s:%d/", host, port)

        def on_shutdown(*_):
            self.stop_event.set()
        signal.signal(signal.SIGTERM, on_shutdown)
        signal.signal(signal.SIGINT, on_shutdown)
        next_market = next_news = next_bot = 0
        try:
            while not self.stop_event.is_set():
                now = time.monotonic()
                if now >= next_news:
                    try:
                        self.poll_news()
                    except Exception:
                        LOG.exception("News run failed")
                    next_news = time.monotonic() + conf["schedule"]["news_seconds"]
                if time.monotonic() >= next_market:
                    self.poll_market()
                    next_market = time.monotonic() + conf["schedule"]["market_seconds"]
                if time.monotonic() >= next_bot:
                    self.telegram.poll_once(self.status_text)
                    next_bot = time.monotonic()+10
                self.stop_event.wait(2)
        finally:
            server.shutdown()
            LOG.info("AFTERBURNER stopped cleanly")
