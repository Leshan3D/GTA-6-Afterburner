# AFTERBURNER v0.1.0 — standalone meme narrative radar

**Purpose:** track 4 GTA-themed BingX USDT perpetual contracts, their candidate Solana spot pools, and GTA VI narrative coverage. **Research alerts only.** No accounts, API secrets, trade placement, paper fills, leverage or orders. This project does not import or touch JAFAR.

## What works

- Public BingX contract active check, latest price, 24h volume, mark/index/funding, open interest, 5m candles and 20-level order book.
- DEX Screener pool lookup by *candidate mint*, strict base-address match, top pool liquidity/volume/price and quote-token context. Candidate mints are **unverified** against futures listings by default.
- GTA/Grand Theft Auto/Rockstar Google News RSS feeds plus optional Reddit RSS, with article deduplication, event tagging, individual source health and explicit distinction between game news and token-specific news.
- Separate directional long/short **research** scores and hard data-quality gates (contract, price, history, spread, depth, liquidity, identity, volume, stale data).
- SQLite WAL: latest snapshots, historical price series, news, health, Telegram cooldown and poll offset.
- Local read-only dashboard `http://127.0.0.1:5056/`, with sparklines, risk flags, story feed and health endpoint; independent Telegram notifications and `/meme`, `/meme GATO`, `/status`, `/help` commands when configured.
- Public API polling and independent Linux user-level systemd service. No modifications to the main JAFAR engine or its files.

## Installation on Omarchy

See `OPENCODE_HANDOFF.md` for the exact assistant instruction and `docs/DEPLOYMENT.md` for manual verification. Copy the archive contents into **`/mnt/jormungandr-rw/AFTERBURNER`**, then:

```bash
cd /mnt/jormungandr-rw/AFTERBURNER
bash ops/install_omarchy.sh
# verify endpoints FIRST, then enable
systemctl --user enable --now afterburner.service
journalctl --user -u afterburner.service -n 100 --no-pager
curl -fsS http://127.0.0.1:5056/healthz
```

The installer creates an isolated venv at `~/.local/share/afterburner/venv`, SQLite at `~/.local/state/afterburner/afterburner.db` and an independent systemd unit. Code lives in the requested mount. A virtualenv inside a possibly NTFS/noexec mount is deliberately avoided.

Edit `config/watchlist.yaml`, `config/settings.yaml`, `config/sources.yaml` to control markets, polling and gates. Configure the optional Telegram bot in `~/.config/afterburner/.env` (created at mode 600 by installer), **not on the mounted source-code drive**. Use a **different Telegram bot token** from JAFAR. An `.env` beside the project is supported only as a development fallback.

## Quick CLI

```bash
~/.local/share/afterburner/venv/bin/python -m afterburner doctor
~/.local/share/afterburner/venv/bin/python -m afterburner once
~/.local/share/afterburner/venv/bin/python -m afterburner status
```

Run from the project root. You may test `once` before the service starts; don't manually launch a second writer while service is running.

## Safety and interpretation

1. **Not verified:** Previously observed Solana candidate addresses are NOT sufficient evidence that the BingX perpetual contracts track those exact spot coins. `mint_verified: false` stays on until an operator finds reliable documented confirmation for **each** symbol. Set `verification_evidence` to a real, reviewable official source. This gate is intentional.
2. **RESEARCH_ONLY:** Strong-looking metrics with identity/liquidity/data defects must never be shown as trade-ready. `REVIEW_CANDIDATE` means review the situation — not approval to buy or sell. Both remain `tradable: false`.
3. **News isn't direction:** Game coverage feeds the narrative counts only. Nothing automatically adds bullish points merely because an official GTA announcement might exist. Google News links are discovery, **not official confirmation**.
4. **No execution:** Neither Binance nor BingX private endpoints exist in this repository. No keys needed. Do not bolt on trading without separate explicit approval and risk verification.
5. **Data caveat:** Spot pool liquidity is different from BingX derivatives depth. Book depth is a rough top-20 USDT estimate, **not guaranteed fill capacity**. Futures OI is a point-in-time level; its change is only available after consecutive samples.
6. **Twitter/X and Telegram chats:** No scraping of private/group content and no fabricated social metrics. These can be added later through authorized access, kept separate from the direction score.
7. **Archive and shutdown:** `systemctl --user disable --now afterburner.service`. Keep database for later assessment or delete the two isolated home directories and code after archiving.

## Code provenance and testing

Architecture borrows JAFAR's ideas (single writer, health-based data quality, human oversight and alert cooldown) from the user-provided `ARCHITECTURE.md`. **There are no runtime imports of JAFAR code.** Tests use deterministic, offline responses; real network endpoints must be validated **on Omarchy**. Source references are documented in `docs/DATA_SOURCES.md`.

```bash
python -m unittest discover -s tests -v
python -m compileall -q afterburner
```
