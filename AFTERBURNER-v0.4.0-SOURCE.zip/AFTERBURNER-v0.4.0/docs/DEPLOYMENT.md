# AFTERBURNER v0.2.0 — Omarchy deployment and verification

**Existing v0.1 deployments:** follow [`../OPENCODE_UPGRADE.md`](../OPENCODE_UPGRADE.md) instead of this clean-install procedure. The v0.2 update must not overwrite your running database or custom watchlist. JAFAR always remains independent and must not be edited.

## Clean install

1. Obtain the archive on the target Omarchy host, inspect the path and verify the files inside. The tarball has one top-level `AFTERBURNER/` directory. Do not execute files from an unknown source.
2. Choose a standalone destination (the original operator uses `/mnt/jormungandr-rw/AFTERBURNER`; friends may choose any other path). Create/extract into a **new empty** directory; do not overwrite existing projects.
3. From the extracted project directory:

```bash
bash ops/install_omarchy.sh
PY="$HOME/.local/share/afterburner/venv/bin/python"
"$PY" -m unittest discover -s tests -v
"$PY" -m afterburner doctor
"$PY" -m afterburner once  # network smoke test; service should still be stopped
"$PY" -m afterburner progress
systemctl --user enable --now afterburner.service
```

The installer creates an isolated venv, state and independent systemd user unit, and does not start the service automatically. Service source stays in the extracted destination. Python 3.11+ is required. If your default Python is incompatible, point `AFTERBURNER_PYTHON=/path/to/python3.11-or-newer` to a separately installed compatible interpreter before installation.

## Validate both dashboard surfaces

```bash
systemctl --user status afterburner.service --no-pager
curl -fsS http://127.0.0.1:5056/healthz
curl -fsS http://127.0.0.1:5056/api/assets | head -c 750
curl -fsS http://127.0.0.1:5057/data.json | head -c 750
curl -s -o /dev/null -w '%{http_code}\n' http://127.0.0.1:5057/api/health
# Expected response for public port's private API route: 404
```

- `:5056` is the **PRIVATE** local dashboard, never share this port beyond localhost.
- `:5057` is the deliberately sanitized **PUBLIC** preview, suitable for an opt-in tunnel or static export. It responds only to `/`, `/index.html`, `/data.json`. Both servers listen on loopback only.
- All market requests use public, read-only APIs; no exchange secrets are needed.
- Four futures symbols are in the watchlist, but exchange responses and Solana mint identities must be verified on the host before interpreting the signals. Never invent successful API results.

## Configure extras

- Telegram setup: [`TELEGRAM.md`](TELEGRAM.md). Tokens live in `~/.config/afterburner/.env` with file mode 600, not in this repository.
- Public sharing: [`PUBLIC_SHARING.md`](PUBLIC_SHARING.md). GitHub Pages is static and won't run the engine. Tailscale Funnel can expose only the sanitized :5057 dashboard while the host is online.
- Update the exported Pages snapshot when desired using `$PY -m afterburner export-public`, review `site/data.json`, and commit it only after the user's approval.

## Rollback and isolation

```bash
systemctl --user disable --now afterburner.service
```

This does not stop JAFAR. To update from an earlier version, back up the stopped service's SQLite state, preserve `config/*.yaml`, and follow the explicit upgrade handoff instead of wiping the directory.
